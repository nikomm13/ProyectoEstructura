import java.io.FileReader;
import java.util.Dictionary;
import java.util.HashMap;
import java.io.*;
import java.util.Scanner;
import java.util.Set;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {

    static Scanner sc = new Scanner (System.in);
    public static HashMap < String, String> diccionario = new HashMap<>();
    public static HashMap <String, String > diccionarioConsejos = new HashMap<>();

    public static void main(String[] args) {

        //llenar diccionarios-------------------------------------------------------------------------------------
        File fichero = new File("src/Diccionario");
        File archivo = new File("src/DiccionarioConsejos");

        try (BufferedReader reader = new BufferedReader(new FileReader(fichero)) ;) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String array2[] = linea.split(";");
                diccionario.put(array2[0], array2[1]);
            }
        }catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
            try (BufferedReader rd = new BufferedReader(new FileReader(archivo))) {
                String linea2;
                while ((linea2 = rd.readLine()) != null) {
                    String array[] = linea2.split(";");
                    diccionarioConsejos.put(array[0], array[1]);
                }
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        //-----------------------------------------------------------------------------------------------------------
            while (true) {
                int opcion = Integer.parseInt(menu());
                switch (opcion) {
                    case 1:
                        System.out.println("Ingrese en lenguaje natural el simbolo que desea buscar");
                        System.out.println(traduce());
                        break;
                    case 2:
                        agregar();
                        break;
                    case 3:
                        consejos();
                        break;
                    case 4:
                        System.exit(0);
                    default:
                        System.out.println("Opción no válida. Por favor, intente nuevamente.");
                }
            }
        }
        public static String menu () {
            System.out.println("Menú");
            System.out.println("-------------------------");
            System.out.println("1. Buscar en el diccionario de latex"); // ver comandos con definicion,
            System.out.println("2. Agregar contenido."); // agregar palabras al diccionario
            System.out.println("3. Necesitas un consejo?"); // yo
            System.out.println("4. salir");
            String x = sc.next();
            return x;
    }
        public static String traduce (){
        sc.nextLine();
        String palabra = sc.nextLine();
            if (diccionario.containsKey(palabra)) {
                return "El simbolo " + palabra + " en lenguaje LaTeX es " + diccionario.get(palabra);
            } else {
                return "La palabra no se encuentra en el diccionario. si deseeas agregala usa la opcion 2.";
            }
        }
        public static void consejos () {
            System.out.println("Hola gracias por usar consejos LaTeX en cual podemos ayudarte");
            System.out.println("Ingrese la palabra de la que desees consejos: ");
            for (String clave : diccionarioConsejos.keySet()){
                System.out.println(clave);
            }
            System.out.println("------------------------------");
            String consejo = sc.next();
            if (diccionarioConsejos.containsKey(consejo)){
                System.out.println(diccionarioConsejos.get(consejo));
            }
        }
        public static void agregar () {
            System.out.println("Ingrese  como la palabra");
            String clave = sc.next();
            if (diccionario.containsKey(clave)) {
                System.out.println("La palabra ya existe");
            } else {
                System.out.println("Ingrese el simbolo");
                String argumento = sc.next();
                diccionario.put(clave, argumento);
                // Añadir la nueva entrada al archivo
                try (FileWriter fw = new FileWriter("src/Diccionario", true);
                     BufferedWriter bw = new BufferedWriter(fw);
                     PrintWriter out = new PrintWriter(bw)) {
                    out.println(clave + ";" + argumento);
                } catch (IOException e) {
                    System.err.println("Error al escribir en el archivo: " + e.getMessage());
                }
            }

        }
}



