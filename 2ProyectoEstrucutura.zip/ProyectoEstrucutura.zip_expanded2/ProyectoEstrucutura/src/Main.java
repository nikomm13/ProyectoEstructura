import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.HashMap;
import java.util.Scanner;

public class Main extends JFrame {

    private static HashMap<String, String> diccionario = new HashMap<>();
    private static HashMap<String, String> diccionarioConsejos = new HashMap<>();
    private Scanner sc = new Scanner(System.in);

    public Main() {
        setTitle("Diccionario LaTeX");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        getContentPane().add(panel);
        panel.setLayout(null);

        JButton buscarButton = new JButton("Buscar en el diccionario");
        buscarButton.setBounds(10, 20, 180, 25);
        panel.add(buscarButton);

        JButton agregarButton = new JButton("Agregar contenido");
        agregarButton.setBounds(200, 20, 180, 25);
        panel.add(agregarButton);

        JButton consejosButton = new JButton("Necesitas un consejo?");
        consejosButton.setBounds(10, 60, 180, 25);
        panel.add(consejosButton);

        JButton salirButton = new JButton("Salir");
        salirButton.setBounds(200, 60, 180, 25);
        panel.add(salirButton);

        buscarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String palabra = JOptionPane.showInputDialog(null, "Ingrese en lenguaje natural el símbolo que desea buscar");
                if (diccionario.containsKey(palabra)) {
                    JOptionPane.showMessageDialog(null, "El símbolo " + palabra + " en lenguaje LaTeX es " + diccionario.get(palabra));
                } else {
                    JOptionPane.showMessageDialog(null, "La palabra no se encuentra en el diccionario. Si deseas agregarla usa la opción 2.");
                }
            }
        });

        agregarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String clave = JOptionPane.showInputDialog(null, "Ingrese la palabra que será usada como clave");
                if (diccionario.containsKey(clave)) {
                    JOptionPane.showMessageDialog(null, "La palabra ya existe");
                } else {
                    String argumento = JOptionPane.showInputDialog(null, "Ingrese el símbolo");
                    diccionario.put(clave, argumento);
                    // Añadir la nueva entrada al archivo
                    try (FileWriter fw = new FileWriter("DIccionario.txt", true);
                         BufferedWriter bw = new BufferedWriter(fw);
                         PrintWriter out = new PrintWriter(bw)) {
                        out.println(clave + ";" + argumento);
                        JOptionPane.showMessageDialog(null, "Palabra agregada correctamente");
                    } catch (IOException ex) {
                        System.err.println("Error al escribir en el archivo: " + ex.getMessage());
                    }
                }
            }
        });

        consejosButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String clave = JOptionPane.showInputDialog(null, "Ingrese la clave para obtener el consejo:");
                if (clave != null && diccionarioConsejos.containsKey(clave)) {
                    String consejo = diccionarioConsejos.get(clave);
                    JOptionPane.showMessageDialog(null, consejo, "Consejo", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "La clave ingresada no es válida", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        salirButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }

    public static void main(String[] args) {
    	llenarDiccionario();
        Main main = new Main();
        main.setVisible(true);
    }

    public static void llenarDiccionario() {
    	File fichero = new File("C:\\Users\\usuario\\Desktop\\ProyectoEstrucutura.zip_expanded\\ProyectoEstrucutura\\src\\DIccionario");
        File archivo = new File("C:\\Users\\usuario\\Desktop\\ProyectoEstrucutura.zip_expanded\\ProyectoEstrucutura\\src\\DIccionarioConsejos");

        try (BufferedReader reader = new BufferedReader(new FileReader(fichero)) ;) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String array2[] = linea.split(";");
                diccionario.put(array2[0], array2[1]);
            }
        }catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
            try (BufferedReader rd = new BufferedReader(new FileReader(archivo))) {
                String linea2;
                while ((linea2 = rd.readLine()) != null) {
                    String array[] = linea2.split(";");
                    diccionarioConsejos.put(array[0], array[1]);
                }
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
    }
}




